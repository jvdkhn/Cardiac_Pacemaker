
#ifndef SENSOR_HH
#define SENSOR_HH

#include "PacemakerProtocol.hh"
#include "umlrtcapsule.hh"
#include "umlrtcapsuleclass.hh"
#include "umlrtlogprotocol.hh"
#include "umlrtmessage.hh"
#include "umlrttimerprotocol.hh"
struct UMLRTCommsPort;
struct UMLRTSlot;

class Capsule_Sensor : public UMLRTCapsule
{
public:
    Capsule_Sensor( const UMLRTCapsuleClass * cd, UMLRTSlot * st, const UMLRTCommsPort * * border, const UMLRTCommsPort * * internal, bool isStat );
protected:
    UMLRTLogProtocol_baserole log;
    PacemakerProtocol::Conj pulsePort;
public:
    enum BorderPortId
    {
        borderport_pulsePort,
        borderport_pulsePortExit
    };
protected:
    PacemakerProtocol::Base pulsePortExit;
    UMLRTTimerProtocol_baserole timing;
public:
    enum InternalPortId
    {
        internalport_timing,
        internalport_log
    };
    enum PartId
    {
    };
    enum PortId
    {
        port_log,
        port_pulsePort,
        port_pulsePortExit,
        port_timing
    };
    virtual void bindPort( bool isBorder, int portId, int index );
    virtual void unbindPort( bool isBorder, int portId, int index );
    int y;
    const int s;
    const int n;
    virtual void inject( const UMLRTMessage & message );
    virtual void initialize( const UMLRTMessage & message );
    const char * getCurrentStateString() const;
private:
    enum State
    {
        Fast,
        Normal,
        Slow,
        WaitingForTheEvent,
        SPECIAL_INTERNAL_STATE_TOP,
        SPECIAL_INTERNAL_STATE_UNVISITED
    };
    const char * stateNames[6];
    State currentState;
    void update_state( State newState );
    void entryaction_____Fast( const UMLRTMessage * msg );
    void entryaction_____Normal( const UMLRTMessage * msg );
    void entryaction_____Slow( const UMLRTMessage * msg );
    void transitionaction_____Initial( const UMLRTMessage * msg );
    void transitionaction_____pulse( const UMLRTMessage * msg );
    bool guard_____normal( const UMLRTMessage * msg );
    bool guard_____slow( const UMLRTMessage * msg );
    void actionchain_____Initial( const UMLRTMessage * msg );
    void actionchain_____fast( const UMLRTMessage * msg );
    void actionchain_____normal( const UMLRTMessage * msg );
    void actionchain_____pulse( const UMLRTMessage * msg );
    void actionchain_____slow( const UMLRTMessage * msg );
    void actionchain_____transition5( const UMLRTMessage * msg );
    void actionchain_____transition6( const UMLRTMessage * msg );
    void actionchain_____transition7( const UMLRTMessage * msg );
    State choice_____subvertex2( const UMLRTMessage * msg );
    State state_____Fast( const UMLRTMessage * msg );
    State state_____Normal( const UMLRTMessage * msg );
    State state_____Slow( const UMLRTMessage * msg );
    State state_____WaitingForTheEvent( const UMLRTMessage * msg );
};
extern const UMLRTCapsuleClass Sensor;

#endif

