
#include "Top.hh"

#include "HeartActivity.hh"
#include "Leads.hh"
#include "PulseGenerator.hh"
#include "Sensor.hh"
#include "umlrtcapsuleclass.hh"
#include "umlrtcapsulepart.hh"
#include "umlrtcommsport.hh"
#include "umlrtframeservice.hh"
#include "umlrtslot.hh"
#include <cstddef>
#include "umlrtcapsulerole.hh"
class UMLRTRtsInterface;

Capsule_Top::Capsule_Top( const UMLRTCapsuleClass * cd, UMLRTSlot * st, const UMLRTCommsPort * * border, const UMLRTCommsPort * * internal, bool isStat )
: UMLRTCapsule( NULL, cd, st, border, internal, isStat )
, heartActivity( &slot->parts[part_heartActivity] )
, leads( &slot->parts[part_leads] )
, pulseGenerator( &slot->parts[part_pulseGenerator] )
, sensor( &slot->parts[part_sensor] )
{
}






void Capsule_Top::bindPort( bool isBorder, int portId, int index )
{
}

void Capsule_Top::unbindPort( bool isBorder, int portId, int index )
{
}

void Capsule_Top::initialize( const UMLRTMessage & msg )
{
}

void Capsule_Top::inject( const UMLRTMessage & msg )
{
}


static const UMLRTCapsuleRole roles[] = 
{
    {
        "heartActivity",
        &HeartActivity,
        1,
        1,
        false,
        false
    },
    {
        "leads",
        &Leads,
        1,
        1,
        false,
        false
    },
    {
        "pulseGenerator",
        &PulseGenerator,
        1,
        1,
        false,
        false
    },
    {
        "sensor",
        &Sensor,
        1,
        1,
        false,
        false
    }
};

static void instantiate_Top( const UMLRTRtsInterface * rts, UMLRTSlot * slot, const UMLRTCommsPort * * borderPorts )
{
    UMLRTFrameService::connectPorts( &slot->parts[Capsule_Top::part_heartActivity].slots[0]->ports[Capsule_HeartActivity::borderport_pulsePort], 0, &slot->parts[Capsule_Top::part_sensor].slots[0]->ports[Capsule_Sensor::borderport_pulsePort], 0 );
    UMLRTFrameService::connectPorts( &slot->parts[Capsule_Top::part_heartActivity].slots[0]->ports[Capsule_HeartActivity::borderport_thresholdPortEntry], 0, &slot->parts[Capsule_Top::part_leads].slots[0]->ports[Capsule_Leads::borderport_thresholdPortExit], 0 );
    UMLRTFrameService::connectPorts( &slot->parts[Capsule_Top::part_leads].slots[0]->ports[Capsule_Leads::borderport_thresholdPortEntry], 0, &slot->parts[Capsule_Top::part_pulseGenerator].slots[0]->ports[Capsule_PulseGenerator::borderport_thresholdPortExit], 0 );
    UMLRTFrameService::connectPorts( &slot->parts[Capsule_Top::part_pulseGenerator].slots[0]->ports[Capsule_PulseGenerator::borderport_pulsePortEntry], 0, &slot->parts[Capsule_Top::part_sensor].slots[0]->ports[Capsule_Sensor::borderport_pulsePortExit], 0 );
    HeartActivity.instantiate( NULL, slot->parts[Capsule_Top::part_heartActivity].slots[0], UMLRTFrameService::createBorderPorts( slot->parts[Capsule_Top::part_heartActivity].slots[0], HeartActivity.numPortRolesBorder ) );
    Leads.instantiate( NULL, slot->parts[Capsule_Top::part_leads].slots[0], UMLRTFrameService::createBorderPorts( slot->parts[Capsule_Top::part_leads].slots[0], Leads.numPortRolesBorder ) );
    PulseGenerator.instantiate( NULL, slot->parts[Capsule_Top::part_pulseGenerator].slots[0], UMLRTFrameService::createBorderPorts( slot->parts[Capsule_Top::part_pulseGenerator].slots[0], PulseGenerator.numPortRolesBorder ) );
    Sensor.instantiate( NULL, slot->parts[Capsule_Top::part_sensor].slots[0], UMLRTFrameService::createBorderPorts( slot->parts[Capsule_Top::part_sensor].slots[0], Sensor.numPortRolesBorder ) );
    slot->capsule = new Capsule_Top( &Top, slot, borderPorts, NULL, false );
}

const UMLRTCapsuleClass Top = 
{
    "Top",
    NULL,
    instantiate_Top,
    4,
    roles,
    0,
    NULL,
    0,
    NULL
};

