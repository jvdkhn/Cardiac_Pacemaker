
#ifndef PACEMAKERPROTOCOL_HH
#define PACEMAKERPROTOCOL_HH

#include "umlrtinsignal.hh"
#include "umlrtoutsignal.hh"
#include "umlrtprotocol.hh"
#include "umlrtsignal.hh"
struct UMLRTCommsPort;

namespace PacemakerProtocol
{
    class Base : public UMLRTProtocol
    {
    public:
        Base( const UMLRTCommsPort * & srcPort );
        UMLRTInSignal e_impulse() const;
        UMLRTOutSignal pulse( int data ) const;
    };
    class Conj : public UMLRTProtocol
    {
    public:
        Conj( const UMLRTCommsPort * & srcPort );
        UMLRTOutSignal e_impulse( int data ) const;
        UMLRTInSignal pulse() const;
    };
    enum SignalId
    {
        signal_e_impulse = UMLRTSignal::FIRST_PROTOCOL_SIGNAL_ID,
        signal_pulse
    };
};

#endif

