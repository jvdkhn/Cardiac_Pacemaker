
#include "Sensor.hh"

#include "PacemakerProtocol.hh"
#include "umlrtcommsportrole.hh"
#include "umlrtmessage.hh"
#include "umlrtslot.hh"
#include "umlrttimerprotocol.hh"
#include <cstddef>
#include "umlrtcapsuleclass.hh"
#include "umlrtframeservice.hh"
class UMLRTRtsInterface;
struct UMLRTCommsPort;

Capsule_Sensor::Capsule_Sensor( const UMLRTCapsuleClass * cd, UMLRTSlot * st, const UMLRTCommsPort * * border, const UMLRTCommsPort * * internal, bool isStat )
: UMLRTCapsule( NULL, cd, st, border, internal, isStat )
, pulsePort( borderPorts[borderport_pulsePort] )
, pulsePortExit( borderPorts[borderport_pulsePortExit] )
, timing( internalPorts[internalport_timing] )
, s( 60 )
, n( 100 )
, currentState( SPECIAL_INTERNAL_STATE_UNVISITED )
{
    stateNames[Fast] = "Fast";
    stateNames[Normal] = "Normal";
    stateNames[Slow] = "Slow";
    stateNames[WaitingForTheEvent] = "WaitingForTheEvent";
    stateNames[SPECIAL_INTERNAL_STATE_TOP] = "<top>";
    stateNames[SPECIAL_INTERNAL_STATE_UNVISITED] = "<uninitialized>";
}









void Capsule_Sensor::bindPort( bool isBorder, int portId, int index )
{
    if( isBorder )
        switch( portId )
        {
        case borderport_pulsePort:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_pulsePort, index, true );
            break;
        case borderport_pulsePortExit:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_pulsePortExit, index, true );
            break;
        }
}

void Capsule_Sensor::unbindPort( bool isBorder, int portId, int index )
{
    if( isBorder )
        switch( portId )
        {
        case borderport_pulsePort:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_pulsePort, index, false );
            UMLRTFrameService::disconnectPort( borderPorts[borderport_pulsePort], index );
            break;
        case borderport_pulsePortExit:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_pulsePortExit, index, false );
            UMLRTFrameService::disconnectPort( borderPorts[borderport_pulsePortExit], index );
            break;
        }
}




void Capsule_Sensor::inject( const UMLRTMessage & message )
{
    msg = &message;
    switch( currentState )
    {
    case WaitingForTheEvent:
        currentState = state_____WaitingForTheEvent( &message );
        break;
    case Slow:
        currentState = state_____Slow( &message );
        break;
    case Fast:
        currentState = state_____Fast( &message );
        break;
    case Normal:
        currentState = state_____Normal( &message );
        break;
    default:
        break;
    }
}

void Capsule_Sensor::initialize( const UMLRTMessage & message )
{
    msg = &message;
    actionchain_____Initial( &message );
    currentState = WaitingForTheEvent;
}

const char * Capsule_Sensor::getCurrentStateString() const
{
    return stateNames[currentState];
}




void Capsule_Sensor::update_state( Capsule_Sensor::State newState )
{
    currentState = newState;
}

void Capsule_Sensor::entryaction_____Fast( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/Pacemaker/Pacemaker.uml Pacemaker::Sensor::Fast entry  */
    log.log("Heart rate = FAST");
    pulsePortExit.pulse(-1).send();
    //dummy timer to move out of state
    timing.informIn(UMLRTTimespec(0,0));
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_Sensor::entryaction_____Normal( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/Pacemaker/Pacemaker.uml Pacemaker::Sensor::Normal entry  */
    log.log("Heart rate = NORMAL");
    log.log("No action taken\n\n");
    pulsePortExit.pulse(0).send();
    //dummy timer to move out of state
    timing.informIn(UMLRTTimespec(0,0));
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_Sensor::entryaction_____Slow( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/Pacemaker/Pacemaker.uml Pacemaker::Sensor::Slow entry  */
    log.log("Heart rate = SLOW");
    log.log("Preparing to normalize the heart rhythm");
    pulsePortExit.pulse(1).send();
    //dummy timer to move out of state
    timing.informIn(UMLRTTimespec(0,0));
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_Sensor::transitionaction_____Initial( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/Pacemaker/Pacemaker.uml Pacemaker::Sensor transition subvertex0,WaitingForTheEvent */
    y = -1;
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_Sensor::transitionaction_____pulse( const UMLRTMessage * msg )
{
    #define data ( *(int *)msg->getParam( 0 ) )
    #define rtdata ( (int *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/Pacemaker/Pacemaker.uml Pacemaker::Sensor transition WaitingForTheEvent,subvertex2,pulse:pulsePort */
    y = data;
    log.log("Current heart rate = %d bpm", data);
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
    #undef data
}

bool Capsule_Sensor::guard_____normal( const UMLRTMessage * msg )
{
    #define data ( *(int *)msg->getParam( 0 ) )
    #define rtdata ( (int *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/Pacemaker/Pacemaker.uml Pacemaker::Sensor guard subvertex2,Normal */
    return y >= s && y <= n;
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
    #undef data
}

bool Capsule_Sensor::guard_____slow( const UMLRTMessage * msg )
{
    #define data ( *(int *)msg->getParam( 0 ) )
    #define rtdata ( (int *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/Pacemaker/Pacemaker.uml Pacemaker::Sensor guard subvertex2,Slow */
    return y < s;
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
    #undef data
}

void Capsule_Sensor::actionchain_____Initial( const UMLRTMessage * msg )
{
    transitionaction_____Initial( msg );
    update_state( WaitingForTheEvent );
}

void Capsule_Sensor::actionchain_____fast( const UMLRTMessage * msg )
{
    update_state( Fast );
    entryaction_____Fast( msg );
}

void Capsule_Sensor::actionchain_____normal( const UMLRTMessage * msg )
{
    update_state( Normal );
    entryaction_____Normal( msg );
}

void Capsule_Sensor::actionchain_____pulse( const UMLRTMessage * msg )
{
    update_state( SPECIAL_INTERNAL_STATE_TOP );
    transitionaction_____pulse( msg );
}

void Capsule_Sensor::actionchain_____slow( const UMLRTMessage * msg )
{
    update_state( Slow );
    entryaction_____Slow( msg );
}

void Capsule_Sensor::actionchain_____transition5( const UMLRTMessage * msg )
{
    update_state( SPECIAL_INTERNAL_STATE_TOP );
    update_state( WaitingForTheEvent );
}

void Capsule_Sensor::actionchain_____transition6( const UMLRTMessage * msg )
{
    update_state( SPECIAL_INTERNAL_STATE_TOP );
    update_state( WaitingForTheEvent );
}

void Capsule_Sensor::actionchain_____transition7( const UMLRTMessage * msg )
{
    update_state( SPECIAL_INTERNAL_STATE_TOP );
    update_state( WaitingForTheEvent );
}

Capsule_Sensor::State Capsule_Sensor::choice_____subvertex2( const UMLRTMessage * msg )
{
    if( guard_____slow( msg ) )
    {
        actionchain_____slow( msg );
        return Slow;
    }
    else if( guard_____normal( msg ) )
    {
        actionchain_____normal( msg );
        return Normal;
    }
    else
    {
        actionchain_____fast( msg );
        return Fast;
    }
    return currentState;
}

Capsule_Sensor::State Capsule_Sensor::state_____Fast( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    case port_timing:
        switch( msg->getSignalId() )
        {
        case UMLRTTimerProtocol::signal_timeout:
            actionchain_____transition7( msg );
            return WaitingForTheEvent;
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}

Capsule_Sensor::State Capsule_Sensor::state_____Normal( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    case port_timing:
        switch( msg->getSignalId() )
        {
        case UMLRTTimerProtocol::signal_timeout:
            actionchain_____transition6( msg );
            return WaitingForTheEvent;
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}

Capsule_Sensor::State Capsule_Sensor::state_____Slow( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    case port_timing:
        switch( msg->getSignalId() )
        {
        case UMLRTTimerProtocol::signal_timeout:
            actionchain_____transition5( msg );
            return WaitingForTheEvent;
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}

Capsule_Sensor::State Capsule_Sensor::state_____WaitingForTheEvent( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    case port_pulsePort:
        switch( msg->getSignalId() )
        {
        case PacemakerProtocol::signal_pulse:
            actionchain_____pulse( msg );
            return choice_____subvertex2( msg );
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}


static const UMLRTCommsPortRole portroles_border[] = 
{
    {
        Capsule_Sensor::port_pulsePort,
        "PacemakerProtocol",
        "pulsePort",
        "",
        1,
        true,
        true,
        false,
        false,
        false,
        false,
        true
    },
    {
        Capsule_Sensor::port_pulsePortExit,
        "PacemakerProtocol",
        "pulsePortExit",
        "",
        1,
        true,
        false,
        false,
        false,
        false,
        false,
        true
    }
};

static const UMLRTCommsPortRole portroles_internal[] = 
{
    {
        Capsule_Sensor::port_timing,
        "Timing",
        "timing",
        "",
        0,
        false,
        false,
        false,
        false,
        true,
        false,
        false
    },
    {
        Capsule_Sensor::port_log,
        "Log",
        "log",
        "",
        0,
        false,
        false,
        false,
        false,
        true,
        false,
        false
    }
};

static void instantiate_Sensor( const UMLRTRtsInterface * rts, UMLRTSlot * slot, const UMLRTCommsPort * * borderPorts )
{
    const UMLRTCommsPort * * internalPorts = UMLRTFrameService::createInternalPorts( slot, &Sensor );
    slot->capsule = new Capsule_Sensor( &Sensor, slot, borderPorts, internalPorts, false );
}

const UMLRTCapsuleClass Sensor = 
{
    "Sensor",
    NULL,
    instantiate_Sensor,
    0,
    NULL,
    2,
    portroles_border,
    2,
    portroles_internal
};

