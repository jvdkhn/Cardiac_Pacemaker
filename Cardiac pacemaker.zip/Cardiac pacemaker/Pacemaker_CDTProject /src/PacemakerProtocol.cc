
#include "PacemakerProtocol.hh"

#include "umlrtinsignal.hh"
#include "umlrtobjectclass.hh"
#include "umlrtoutsignal.hh"
struct UMLRTCommsPort;

static UMLRTObject_field fields_e_impulse[] = 
{
    {
        "data",
        &UMLRTType_int,
        0,
        1,
        0
    }
};

static UMLRTObject payload_e_impulse = 
{
    sizeof( int ),
    1,
    fields_e_impulse
};

static UMLRTObject_field fields_pulse[] = 
{
    {
        "data",
        &UMLRTType_int,
        0,
        1,
        0
    }
};

static UMLRTObject payload_pulse = 
{
    sizeof( int ),
    1,
    fields_pulse
};

PacemakerProtocol::Base::Base( const UMLRTCommsPort * & srcPort )
: UMLRTProtocol( srcPort )
{
}

UMLRTInSignal PacemakerProtocol::Base::e_impulse() const
{
    UMLRTInSignal signal;
    signal.initialize( "e_impulse", signal_e_impulse, srcPort, &payload_e_impulse );
    return signal;
}

UMLRTOutSignal PacemakerProtocol::Base::pulse( int data ) const
{
    UMLRTOutSignal signal;
    signal.initialize( "pulse", signal_pulse, srcPort, &payload_pulse, &data );
    return signal;
}

PacemakerProtocol::Conj::Conj( const UMLRTCommsPort * & srcPort )
: UMLRTProtocol( srcPort )
{
}

UMLRTOutSignal PacemakerProtocol::Conj::e_impulse( int data ) const
{
    UMLRTOutSignal signal;
    signal.initialize( "e_impulse", signal_e_impulse, srcPort, &payload_e_impulse, &data );
    return signal;
}

UMLRTInSignal PacemakerProtocol::Conj::pulse() const
{
    UMLRTInSignal signal;
    signal.initialize( "pulse", signal_pulse, srcPort, &payload_pulse );
    return signal;
}


