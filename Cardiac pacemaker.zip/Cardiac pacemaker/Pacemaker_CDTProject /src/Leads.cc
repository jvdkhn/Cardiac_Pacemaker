
#include "Leads.hh"

#include "PacemakerProtocol.hh"
#include "umlrtcommsportrole.hh"
#include "umlrtmessage.hh"
#include "umlrtslot.hh"
#include <cstddef>
#include "umlrtcapsuleclass.hh"
#include "umlrtframeservice.hh"
class UMLRTRtsInterface;
struct UMLRTCommsPort;

Capsule_Leads::Capsule_Leads( const UMLRTCapsuleClass * cd, UMLRTSlot * st, const UMLRTCommsPort * * border, const UMLRTCommsPort * * internal, bool isStat )
: UMLRTCapsule( NULL, cd, st, border, internal, isStat )
, thresholdPortEntry( borderPorts[borderport_thresholdPortEntry] )
, thresholdPortExit( borderPorts[borderport_thresholdPortExit] )
, currentState( SPECIAL_INTERNAL_STATE_UNVISITED )
{
    stateNames[State1] = "State1";
    stateNames[SPECIAL_INTERNAL_STATE_TOP] = "<top>";
    stateNames[SPECIAL_INTERNAL_STATE_UNVISITED] = "<uninitialized>";
}








void Capsule_Leads::bindPort( bool isBorder, int portId, int index )
{
    if( isBorder )
        switch( portId )
        {
        case borderport_thresholdPortEntry:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_thresholdPortEntry, index, true );
            break;
        case borderport_thresholdPortExit:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_thresholdPortExit, index, true );
            break;
        }
}

void Capsule_Leads::unbindPort( bool isBorder, int portId, int index )
{
    if( isBorder )
        switch( portId )
        {
        case borderport_thresholdPortEntry:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_thresholdPortEntry, index, false );
            UMLRTFrameService::disconnectPort( borderPorts[borderport_thresholdPortEntry], index );
            break;
        case borderport_thresholdPortExit:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_thresholdPortExit, index, false );
            UMLRTFrameService::disconnectPort( borderPorts[borderport_thresholdPortExit], index );
            break;
        }
}


void Capsule_Leads::inject( const UMLRTMessage & message )
{
    msg = &message;
    switch( currentState )
    {
    case State1:
        currentState = state_____State1( &message );
        break;
    default:
        break;
    }
}

void Capsule_Leads::initialize( const UMLRTMessage & message )
{
    msg = &message;
    actionchain_____Initial( &message );
    currentState = State1;
}

const char * Capsule_Leads::getCurrentStateString() const
{
    return stateNames[currentState];
}




void Capsule_Leads::update_state( Capsule_Leads::State newState )
{
    currentState = newState;
}

void Capsule_Leads::transitionaction_____get( const UMLRTMessage * msg )
{
    #define data ( *(int *)msg->getParam( 0 ) )
    #define rtdata ( (int *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/Pacemaker/Pacemaker.uml Pacemaker::Leads transition State1,State1,e_impulse:thresholdPortEntry */
    voltage=data;
    thresholdPortExit.e_impulse(voltage).send();
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
    #undef data
}

void Capsule_Leads::actionchain_____Initial( const UMLRTMessage * msg )
{
    update_state( State1 );
}

void Capsule_Leads::actionchain_____get( const UMLRTMessage * msg )
{
    update_state( SPECIAL_INTERNAL_STATE_TOP );
    transitionaction_____get( msg );
    update_state( State1 );
}

Capsule_Leads::State Capsule_Leads::state_____State1( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    case port_thresholdPortEntry:
        switch( msg->getSignalId() )
        {
        case PacemakerProtocol::signal_e_impulse:
            actionchain_____get( msg );
            return State1;
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}


static const UMLRTCommsPortRole portroles_border[] = 
{
    {
        Capsule_Leads::port_thresholdPortEntry,
        "PacemakerProtocol",
        "thresholdPortEntry",
        "",
        1,
        true,
        false,
        false,
        false,
        false,
        false,
        true
    },
    {
        Capsule_Leads::port_thresholdPortExit,
        "PacemakerProtocol",
        "thresholdPortExit",
        "",
        1,
        true,
        true,
        false,
        false,
        false,
        false,
        true
    }
};

static const UMLRTCommsPortRole portroles_internal[] = 
{
    {
        Capsule_Leads::port_log,
        "Log",
        "log",
        "",
        0,
        false,
        false,
        false,
        false,
        true,
        false,
        false
    }
};

static void instantiate_Leads( const UMLRTRtsInterface * rts, UMLRTSlot * slot, const UMLRTCommsPort * * borderPorts )
{
    const UMLRTCommsPort * * internalPorts = UMLRTFrameService::createInternalPorts( slot, &Leads );
    slot->capsule = new Capsule_Leads( &Leads, slot, borderPorts, internalPorts, false );
}

const UMLRTCapsuleClass Leads = 
{
    "Leads",
    NULL,
    instantiate_Leads,
    0,
    NULL,
    2,
    portroles_border,
    1,
    portroles_internal
};

