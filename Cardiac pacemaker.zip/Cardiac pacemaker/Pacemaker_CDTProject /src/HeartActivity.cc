
#include "HeartActivity.hh"

#include "PacemakerProtocol.hh"
#include "umlrtcommsportrole.hh"
#include "umlrtmessage.hh"
#include "umlrtslot.hh"
#include "umlrttimerprotocol.hh"
#include <cstddef>
#include "umlrtcapsuleclass.hh"
#include "umlrtframeservice.hh"
class UMLRTRtsInterface;
struct UMLRTCommsPort;

Capsule_HeartActivity::Capsule_HeartActivity( const UMLRTCapsuleClass * cd, UMLRTSlot * st, const UMLRTCommsPort * * border, const UMLRTCommsPort * * internal, bool isStat )
: UMLRTCapsule( NULL, cd, st, border, internal, isStat )
, pulsePort( borderPorts[borderport_pulsePort] )
, thresholdPortEntry( borderPorts[borderport_thresholdPortEntry] )
, timing( internalPorts[internalport_timing] )
, ULV( 125 )
, LLV( 35 )
, currentState( SPECIAL_INTERNAL_STATE_UNVISITED )
{
    stateNames[State1] = "State1";
    stateNames[State2] = "State2";
    stateNames[SPECIAL_INTERNAL_STATE_TOP] = "<top>";
    stateNames[SPECIAL_INTERNAL_STATE_UNVISITED] = "<uninitialized>";
}









void Capsule_HeartActivity::bindPort( bool isBorder, int portId, int index )
{
    if( isBorder )
        switch( portId )
        {
        case borderport_pulsePort:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_pulsePort, index, true );
            break;
        case borderport_thresholdPortEntry:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_thresholdPortEntry, index, true );
            break;
        }
}

void Capsule_HeartActivity::unbindPort( bool isBorder, int portId, int index )
{
    if( isBorder )
        switch( portId )
        {
        case borderport_pulsePort:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_pulsePort, index, false );
            UMLRTFrameService::disconnectPort( borderPorts[borderport_pulsePort], index );
            break;
        case borderport_thresholdPortEntry:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_thresholdPortEntry, index, false );
            UMLRTFrameService::disconnectPort( borderPorts[borderport_thresholdPortEntry], index );
            break;
        }
}





void Capsule_HeartActivity::inject( const UMLRTMessage & message )
{
    msg = &message;
    switch( currentState )
    {
    case State1:
        currentState = state_____State1( &message );
        break;
    case State2:
        currentState = state_____State2( &message );
        break;
    default:
        break;
    }
}

void Capsule_HeartActivity::initialize( const UMLRTMessage & message )
{
    msg = &message;
    actionchain_____Initial( &message );
    currentState = State1;
}

const char * Capsule_HeartActivity::getCurrentStateString() const
{
    return stateNames[currentState];
}




void Capsule_HeartActivity::update_state( Capsule_HeartActivity::State newState )
{
    currentState = newState;
}

void Capsule_HeartActivity::entryaction_____State1( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/Pacemaker/Pacemaker.uml Pacemaker::HeartActivity::State1 entry  */
    timing.informIn(UMLRTTimespec(3,0));
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_HeartActivity::entryaction_____State2( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/Pacemaker/Pacemaker.uml Pacemaker::HeartActivity::State2 entry  */
    pulsePort.pulse(x).send();
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_HeartActivity::transitionaction_____Initial( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/Pacemaker/Pacemaker.uml Pacemaker::HeartActivity transition subvertex0,State1 */
    log.log("Heart is ready to send the signals");
    x = rand() % 80 + 40;
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_HeartActivity::transitionaction_____next_pulse( const UMLRTMessage * msg )
{
    #define data ( *(int *)msg->getParam( 0 ) )
    #define rtdata ( (int *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/Pacemaker/Pacemaker.uml Pacemaker::HeartActivity transition State2,subvertex3,e_impulse:thresholdPortEntry */
    voltage=data;
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
    #undef data
}

void Capsule_HeartActivity::transitionaction_____transition4( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/Pacemaker/Pacemaker.uml Pacemaker::HeartActivity transition subvertex3,State1 */
    x = x + (rand() % 20 + (-10));
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_HeartActivity::transitionaction_____voltage_0( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/Pacemaker/Pacemaker.uml Pacemaker::HeartActivity transition subvertex3,State1 */
    log.log("Delivered electricity = %d V and Duration = 0.5 ms", voltage);
    x = x + (75-x);
    log.log("Heart rhythm normalized\n\n");
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

bool Capsule_HeartActivity::guard_____voltage_0( const UMLRTMessage * msg )
{
    #define data ( *(int *)msg->getParam( 0 ) )
    #define rtdata ( (int *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/Pacemaker/Pacemaker.uml Pacemaker::HeartActivity guard subvertex3,State1 */
    return voltage > 0;
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
    #undef data
}

void Capsule_HeartActivity::actionchain_____Initial( const UMLRTMessage * msg )
{
    transitionaction_____Initial( msg );
    update_state( State1 );
    entryaction_____State1( msg );
}

void Capsule_HeartActivity::actionchain_____next_pulse( const UMLRTMessage * msg )
{
    update_state( SPECIAL_INTERNAL_STATE_TOP );
    transitionaction_____next_pulse( msg );
}

void Capsule_HeartActivity::actionchain_____timeout( const UMLRTMessage * msg )
{
    update_state( SPECIAL_INTERNAL_STATE_TOP );
    update_state( State2 );
    entryaction_____State2( msg );
}

void Capsule_HeartActivity::actionchain_____transition4( const UMLRTMessage * msg )
{
    transitionaction_____transition4( msg );
    update_state( State1 );
    entryaction_____State1( msg );
}

void Capsule_HeartActivity::actionchain_____voltage_0( const UMLRTMessage * msg )
{
    transitionaction_____voltage_0( msg );
    update_state( State1 );
    entryaction_____State1( msg );
}

Capsule_HeartActivity::State Capsule_HeartActivity::choice_____subvertex3( const UMLRTMessage * msg )
{
    if( guard_____voltage_0( msg ) )
    {
        actionchain_____voltage_0( msg );
        return State1;
    }
    else
    {
        actionchain_____transition4( msg );
        return State1;
    }
    return currentState;
}

Capsule_HeartActivity::State Capsule_HeartActivity::state_____State1( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    case port_timing:
        switch( msg->getSignalId() )
        {
        case UMLRTTimerProtocol::signal_timeout:
            actionchain_____timeout( msg );
            return State2;
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}

Capsule_HeartActivity::State Capsule_HeartActivity::state_____State2( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    case port_thresholdPortEntry:
        switch( msg->getSignalId() )
        {
        case PacemakerProtocol::signal_e_impulse:
            actionchain_____next_pulse( msg );
            return choice_____subvertex3( msg );
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}


static const UMLRTCommsPortRole portroles_border[] = 
{
    {
        Capsule_HeartActivity::port_pulsePort,
        "PacemakerProtocol",
        "pulsePort",
        "",
        1,
        true,
        false,
        false,
        false,
        false,
        false,
        true
    },
    {
        Capsule_HeartActivity::port_thresholdPortEntry,
        "PacemakerProtocol",
        "thresholdPortEntry",
        "",
        1,
        true,
        false,
        false,
        false,
        false,
        false,
        true
    }
};

static const UMLRTCommsPortRole portroles_internal[] = 
{
    {
        Capsule_HeartActivity::port_timing,
        "Timing",
        "timing",
        "",
        0,
        false,
        false,
        false,
        false,
        true,
        false,
        false
    },
    {
        Capsule_HeartActivity::port_log,
        "Log",
        "log",
        "",
        0,
        false,
        false,
        false,
        false,
        true,
        false,
        false
    }
};

static void instantiate_HeartActivity( const UMLRTRtsInterface * rts, UMLRTSlot * slot, const UMLRTCommsPort * * borderPorts )
{
    const UMLRTCommsPort * * internalPorts = UMLRTFrameService::createInternalPorts( slot, &HeartActivity );
    slot->capsule = new Capsule_HeartActivity( &HeartActivity, slot, borderPorts, internalPorts, false );
}

const UMLRTCapsuleClass HeartActivity = 
{
    "HeartActivity",
    NULL,
    instantiate_HeartActivity,
    0,
    NULL,
    2,
    portroles_border,
    2,
    portroles_internal
};

