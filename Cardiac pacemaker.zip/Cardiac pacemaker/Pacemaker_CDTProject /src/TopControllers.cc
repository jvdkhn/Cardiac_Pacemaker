
#include "TopControllers.hh"

#include "HeartActivity.hh"
#include "Leads.hh"
#include "PulseGenerator.hh"
#include "Sensor.hh"
#include "Top.hh"
#include "umlrtcapsuleclass.hh"
#include "umlrtcapsulepart.hh"
#include "umlrtcommsport.hh"
#include "umlrtcommsportfarend.hh"
#include "umlrtcontroller.hh"
#include "umlrtslot.hh"
#include <cstddef>


static UMLRTController DefaultController_( "DefaultController" );

UMLRTController * DefaultController = &DefaultController_;

static Capsule_Top top( &Top, &Top_slots[InstId_Top], NULL, NULL, true );

static UMLRTSlot * slots_Top[] = 
{
    &Top_slots[InstId_Top_heartActivity],
    &Top_slots[InstId_Top_leads],
    &Top_slots[InstId_Top_pulseGenerator],
    &Top_slots[InstId_Top_sensor]
};

static UMLRTCapsulePart parts_Top[] = 
{
    {
        &Top,
        Capsule_Top::part_heartActivity,
        1,
        &slots_Top[0]
    },
    {
        &Top,
        Capsule_Top::part_leads,
        1,
        &slots_Top[1]
    },
    {
        &Top,
        Capsule_Top::part_pulseGenerator,
        1,
        &slots_Top[2]
    },
    {
        &Top,
        Capsule_Top::part_sensor,
        1,
        &slots_Top[3]
    }
};

static UMLRTCommsPortFarEnd borderfarEndList_Top_heartActivity[] = 
{
    {
        0,
        &borderports_Top_sensor[Capsule_Sensor::borderport_pulsePort]
    },
    {
        0,
        &borderports_Top_leads[Capsule_Leads::borderport_thresholdPortExit]
    }
};

UMLRTCommsPort borderports_Top_heartActivity[] = 
{
    {
        &HeartActivity,
        Capsule_HeartActivity::borderport_pulsePort,
        &Top_slots[InstId_Top_heartActivity],
        1,
        borderfarEndList_Top_heartActivity,
        NULL,
        NULL,
        "",
        true,
        true,
        true,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        true
    },
    {
        &HeartActivity,
        Capsule_HeartActivity::borderport_thresholdPortEntry,
        &Top_slots[InstId_Top_heartActivity],
        1,
        &borderfarEndList_Top_heartActivity[1],
        NULL,
        NULL,
        "",
        true,
        true,
        true,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        true
    }
};

static const UMLRTCommsPort * borderports_Top_heartActivity_ptrs[] = 
{
    &borderports_Top_heartActivity[0],
    &borderports_Top_heartActivity[1]
};

static UMLRTCommsPortFarEnd internalfarEndList_Top_heartActivity[] = 
{
    {
        0,
        NULL
    },
    {
        0,
        NULL
    }
};

UMLRTCommsPort internalports_Top_heartActivity[] = 
{
    {
        &HeartActivity,
        Capsule_HeartActivity::internalport_timing,
        &Top_slots[InstId_Top_heartActivity],
        1,
        &internalfarEndList_Top_heartActivity[1],
        NULL,
        NULL,
        "",
        true,
        false,
        true,
        false,
        false,
        false,
        false,
        true,
        false,
        false,
        false
    },
    {
        &HeartActivity,
        Capsule_HeartActivity::internalport_log,
        &Top_slots[InstId_Top_heartActivity],
        1,
        internalfarEndList_Top_heartActivity,
        NULL,
        NULL,
        "",
        true,
        false,
        true,
        false,
        false,
        false,
        false,
        true,
        false,
        false,
        false
    }
};

static const UMLRTCommsPort * internalports_Top_heartActivity_ptrs[] = 
{
    &internalports_Top_heartActivity[0],
    &internalports_Top_heartActivity[1]
};

static Capsule_HeartActivity top_heartActivity( &HeartActivity, &Top_slots[InstId_Top_heartActivity], borderports_Top_heartActivity_ptrs, internalports_Top_heartActivity_ptrs, true );

static UMLRTCommsPortFarEnd borderfarEndList_Top_leads[] = 
{
    {
        0,
        &borderports_Top_pulseGenerator[Capsule_PulseGenerator::borderport_thresholdPortExit]
    },
    {
        0,
        &borderports_Top_heartActivity[Capsule_HeartActivity::borderport_thresholdPortEntry]
    }
};

UMLRTCommsPort borderports_Top_leads[] = 
{
    {
        &Leads,
        Capsule_Leads::borderport_thresholdPortEntry,
        &Top_slots[InstId_Top_leads],
        1,
        borderfarEndList_Top_leads,
        NULL,
        NULL,
        "",
        true,
        true,
        true,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        true
    },
    {
        &Leads,
        Capsule_Leads::borderport_thresholdPortExit,
        &Top_slots[InstId_Top_leads],
        1,
        &borderfarEndList_Top_leads[1],
        NULL,
        NULL,
        "",
        true,
        true,
        true,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        true
    }
};

static const UMLRTCommsPort * borderports_Top_leads_ptrs[] = 
{
    &borderports_Top_leads[0],
    &borderports_Top_leads[1]
};

static UMLRTCommsPortFarEnd internalfarEndList_Top_leads[] = 
{
    {
        0,
        NULL
    }
};

UMLRTCommsPort internalports_Top_leads[] = 
{
    {
        &Leads,
        Capsule_Leads::internalport_log,
        &Top_slots[InstId_Top_leads],
        1,
        internalfarEndList_Top_leads,
        NULL,
        NULL,
        "",
        true,
        false,
        true,
        false,
        false,
        false,
        false,
        true,
        false,
        false,
        false
    }
};

static const UMLRTCommsPort * internalports_Top_leads_ptrs[] = 
{
    &internalports_Top_leads[0]
};

static Capsule_Leads top_leads( &Leads, &Top_slots[InstId_Top_leads], borderports_Top_leads_ptrs, internalports_Top_leads_ptrs, true );

static UMLRTCommsPortFarEnd borderfarEndList_Top_pulseGenerator[] = 
{
    {
        0,
        &borderports_Top_sensor[Capsule_Sensor::borderport_pulsePortExit]
    },
    {
        0,
        &borderports_Top_leads[Capsule_Leads::borderport_thresholdPortEntry]
    }
};

UMLRTCommsPort borderports_Top_pulseGenerator[] = 
{
    {
        &PulseGenerator,
        Capsule_PulseGenerator::borderport_pulsePortEntry,
        &Top_slots[InstId_Top_pulseGenerator],
        1,
        borderfarEndList_Top_pulseGenerator,
        NULL,
        NULL,
        "",
        true,
        true,
        true,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        true
    },
    {
        &PulseGenerator,
        Capsule_PulseGenerator::borderport_thresholdPortExit,
        &Top_slots[InstId_Top_pulseGenerator],
        1,
        &borderfarEndList_Top_pulseGenerator[1],
        NULL,
        NULL,
        "",
        true,
        true,
        true,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        true
    }
};

static const UMLRTCommsPort * borderports_Top_pulseGenerator_ptrs[] = 
{
    &borderports_Top_pulseGenerator[0],
    &borderports_Top_pulseGenerator[1]
};

static UMLRTCommsPortFarEnd internalfarEndList_Top_pulseGenerator[] = 
{
    {
        0,
        NULL
    },
    {
        0,
        NULL
    }
};

UMLRTCommsPort internalports_Top_pulseGenerator[] = 
{
    {
        &PulseGenerator,
        Capsule_PulseGenerator::internalport_timing,
        &Top_slots[InstId_Top_pulseGenerator],
        1,
        &internalfarEndList_Top_pulseGenerator[1],
        NULL,
        NULL,
        "",
        true,
        false,
        true,
        false,
        false,
        false,
        false,
        true,
        false,
        false,
        false
    },
    {
        &PulseGenerator,
        Capsule_PulseGenerator::internalport_log,
        &Top_slots[InstId_Top_pulseGenerator],
        1,
        internalfarEndList_Top_pulseGenerator,
        NULL,
        NULL,
        "",
        true,
        false,
        true,
        false,
        false,
        false,
        false,
        true,
        false,
        false,
        false
    }
};

static const UMLRTCommsPort * internalports_Top_pulseGenerator_ptrs[] = 
{
    &internalports_Top_pulseGenerator[0],
    &internalports_Top_pulseGenerator[1]
};

static Capsule_PulseGenerator top_pulseGenerator( &PulseGenerator, &Top_slots[InstId_Top_pulseGenerator], borderports_Top_pulseGenerator_ptrs, internalports_Top_pulseGenerator_ptrs, true );

static UMLRTCommsPortFarEnd borderfarEndList_Top_sensor[] = 
{
    {
        0,
        &borderports_Top_heartActivity[Capsule_HeartActivity::borderport_pulsePort]
    },
    {
        0,
        &borderports_Top_pulseGenerator[Capsule_PulseGenerator::borderport_pulsePortEntry]
    }
};

UMLRTCommsPort borderports_Top_sensor[] = 
{
    {
        &Sensor,
        Capsule_Sensor::borderport_pulsePort,
        &Top_slots[InstId_Top_sensor],
        1,
        borderfarEndList_Top_sensor,
        NULL,
        NULL,
        "",
        true,
        true,
        true,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        true
    },
    {
        &Sensor,
        Capsule_Sensor::borderport_pulsePortExit,
        &Top_slots[InstId_Top_sensor],
        1,
        &borderfarEndList_Top_sensor[1],
        NULL,
        NULL,
        "",
        true,
        true,
        true,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        true
    }
};

static const UMLRTCommsPort * borderports_Top_sensor_ptrs[] = 
{
    &borderports_Top_sensor[0],
    &borderports_Top_sensor[1]
};

static UMLRTCommsPortFarEnd internalfarEndList_Top_sensor[] = 
{
    {
        0,
        NULL
    },
    {
        0,
        NULL
    }
};

UMLRTCommsPort internalports_Top_sensor[] = 
{
    {
        &Sensor,
        Capsule_Sensor::internalport_timing,
        &Top_slots[InstId_Top_sensor],
        1,
        &internalfarEndList_Top_sensor[1],
        NULL,
        NULL,
        "",
        true,
        false,
        true,
        false,
        false,
        false,
        false,
        true,
        false,
        false,
        false
    },
    {
        &Sensor,
        Capsule_Sensor::internalport_log,
        &Top_slots[InstId_Top_sensor],
        1,
        internalfarEndList_Top_sensor,
        NULL,
        NULL,
        "",
        true,
        false,
        true,
        false,
        false,
        false,
        false,
        true,
        false,
        false,
        false
    }
};

static const UMLRTCommsPort * internalports_Top_sensor_ptrs[] = 
{
    &internalports_Top_sensor[0],
    &internalports_Top_sensor[1]
};

static Capsule_Sensor top_sensor( &Sensor, &Top_slots[InstId_Top_sensor], borderports_Top_sensor_ptrs, internalports_Top_sensor_ptrs, true );

UMLRTSlot Top_slots[] = 
{
    {
        "Top",
        0,
        &Top,
        NULL,
        0,
        &top,
        &DefaultController_,
        4,
        parts_Top,
        0,
        NULL,
        NULL,
        true,
        false
    },
    {
        "Top.heartActivity",
        0,
        &HeartActivity,
        &Top,
        Capsule_Top::part_heartActivity,
        &top_heartActivity,
        &DefaultController_,
        0,
        NULL,
        2,
        borderports_Top_heartActivity,
        NULL,
        true,
        false
    },
    {
        "Top.leads",
        0,
        &Leads,
        &Top,
        Capsule_Top::part_leads,
        &top_leads,
        &DefaultController_,
        0,
        NULL,
        2,
        borderports_Top_leads,
        NULL,
        true,
        false
    },
    {
        "Top.pulseGenerator",
        0,
        &PulseGenerator,
        &Top,
        Capsule_Top::part_pulseGenerator,
        &top_pulseGenerator,
        &DefaultController_,
        0,
        NULL,
        2,
        borderports_Top_pulseGenerator,
        NULL,
        true,
        false
    },
    {
        "Top.sensor",
        0,
        &Sensor,
        &Top,
        Capsule_Top::part_sensor,
        &top_sensor,
        &DefaultController_,
        0,
        NULL,
        2,
        borderports_Top_sensor,
        NULL,
        true,
        false
    }
};

