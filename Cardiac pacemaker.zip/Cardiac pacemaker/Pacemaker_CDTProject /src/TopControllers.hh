
#ifndef TOPCONTROLLERS_HH
#define TOPCONTROLLERS_HH

class UMLRTController;
struct UMLRTCommsPort;
struct UMLRTSlot;

enum CapsuleInstanceId
{
    InstId_Top,
    InstId_Top_heartActivity,
    InstId_Top_leads,
    InstId_Top_pulseGenerator,
    InstId_Top_sensor
};
extern UMLRTController * DefaultController;
extern UMLRTCommsPort borderports_Top_heartActivity[];
extern UMLRTCommsPort internalports_Top_heartActivity[];
extern UMLRTCommsPort borderports_Top_leads[];
extern UMLRTCommsPort internalports_Top_leads[];
extern UMLRTCommsPort borderports_Top_pulseGenerator[];
extern UMLRTCommsPort internalports_Top_pulseGenerator[];
extern UMLRTCommsPort borderports_Top_sensor[];
extern UMLRTCommsPort internalports_Top_sensor[];
extern UMLRTSlot Top_slots[];

#endif

