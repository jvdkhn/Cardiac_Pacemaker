
#include "PulseGenerator.hh"

#include "PacemakerProtocol.hh"
#include "umlrtcommsportrole.hh"
#include "umlrtmessage.hh"
#include "umlrtslot.hh"
#include "umlrttimerprotocol.hh"
#include <cstddef>
#include "umlrtcapsuleclass.hh"
#include "umlrtframeservice.hh"
class UMLRTRtsInterface;
struct UMLRTCommsPort;

Capsule_PulseGenerator::Capsule_PulseGenerator( const UMLRTCapsuleClass * cd, UMLRTSlot * st, const UMLRTCommsPort * * border, const UMLRTCommsPort * * internal, bool isStat )
: UMLRTCapsule( NULL, cd, st, border, internal, isStat )
, pulsePortEntry( borderPorts[borderport_pulsePortEntry] )
, thresholdPortExit( borderPorts[borderport_thresholdPortExit] )
, timing( internalPorts[internalport_timing] )
, v( 2 )
, currentState( SPECIAL_INTERNAL_STATE_UNVISITED )
{
    stateNames[State2] = "State2";
    stateNames[Waiting] = "Waiting";
    stateNames[SPECIAL_INTERNAL_STATE_TOP] = "<top>";
    stateNames[SPECIAL_INTERNAL_STATE_UNVISITED] = "<uninitialized>";
}









void Capsule_PulseGenerator::bindPort( bool isBorder, int portId, int index )
{
    if( isBorder )
        switch( portId )
        {
        case borderport_pulsePortEntry:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_pulsePortEntry, index, true );
            break;
        case borderport_thresholdPortExit:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_thresholdPortExit, index, true );
            break;
        }
}

void Capsule_PulseGenerator::unbindPort( bool isBorder, int portId, int index )
{
    if( isBorder )
        switch( portId )
        {
        case borderport_pulsePortEntry:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_pulsePortEntry, index, false );
            UMLRTFrameService::disconnectPort( borderPorts[borderport_pulsePortEntry], index );
            break;
        case borderport_thresholdPortExit:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_thresholdPortExit, index, false );
            UMLRTFrameService::disconnectPort( borderPorts[borderport_thresholdPortExit], index );
            break;
        }
}



void Capsule_PulseGenerator::inject( const UMLRTMessage & message )
{
    msg = &message;
    switch( currentState )
    {
    case Waiting:
        currentState = state_____Waiting( &message );
        break;
    case State2:
        currentState = state_____State2( &message );
        break;
    default:
        break;
    }
}

void Capsule_PulseGenerator::initialize( const UMLRTMessage & message )
{
    msg = &message;
    actionchain_____Initial( &message );
    currentState = Waiting;
}

const char * Capsule_PulseGenerator::getCurrentStateString() const
{
    return stateNames[currentState];
}




void Capsule_PulseGenerator::update_state( Capsule_PulseGenerator::State newState )
{
    currentState = newState;
}

void Capsule_PulseGenerator::entryaction_____State2( const UMLRTMessage * msg )
{
    #define data ( *(int *)msg->getParam( 0 ) )
    #define rtdata ( (int *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/Pacemaker/Pacemaker.uml Pacemaker::PulseGenerator::State2 entry  */
    if(z>0)
    thresholdPortExit.e_impulse(v).send();
    else 
    thresholdPortExit.e_impulse(z).send();
    //dummy timer to move out of state
    timing.informIn(UMLRTTimespec(0,0));
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
    #undef data
}

void Capsule_PulseGenerator::transitionaction_____Initial( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/Pacemaker/Pacemaker.uml Pacemaker::PulseGenerator transition subvertex0,Waiting */
    z=-1;
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_PulseGenerator::transitionaction_____pulse( const UMLRTMessage * msg )
{
    #define data ( *(int *)msg->getParam( 0 ) )
    #define rtdata ( (int *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/Pacemaker/Pacemaker.uml Pacemaker::PulseGenerator transition Waiting,State2,pulse:pulsePortEntry */
    z = data;
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
    #undef data
}

void Capsule_PulseGenerator::actionchain_____Initial( const UMLRTMessage * msg )
{
    transitionaction_____Initial( msg );
    update_state( Waiting );
}

void Capsule_PulseGenerator::actionchain_____pulse( const UMLRTMessage * msg )
{
    update_state( SPECIAL_INTERNAL_STATE_TOP );
    transitionaction_____pulse( msg );
    update_state( State2 );
    entryaction_____State2( msg );
}

void Capsule_PulseGenerator::actionchain_____transition2( const UMLRTMessage * msg )
{
    update_state( SPECIAL_INTERNAL_STATE_TOP );
    update_state( Waiting );
}

Capsule_PulseGenerator::State Capsule_PulseGenerator::state_____State2( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    case port_timing:
        switch( msg->getSignalId() )
        {
        case UMLRTTimerProtocol::signal_timeout:
            actionchain_____transition2( msg );
            return Waiting;
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}

Capsule_PulseGenerator::State Capsule_PulseGenerator::state_____Waiting( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    case port_pulsePortEntry:
        switch( msg->getSignalId() )
        {
        case PacemakerProtocol::signal_pulse:
            actionchain_____pulse( msg );
            return State2;
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}


static const UMLRTCommsPortRole portroles_border[] = 
{
    {
        Capsule_PulseGenerator::port_pulsePortEntry,
        "PacemakerProtocol",
        "pulsePortEntry",
        "",
        1,
        true,
        true,
        false,
        false,
        false,
        false,
        true
    },
    {
        Capsule_PulseGenerator::port_thresholdPortExit,
        "PacemakerProtocol",
        "thresholdPortExit",
        "",
        1,
        true,
        true,
        false,
        false,
        false,
        false,
        true
    }
};

static const UMLRTCommsPortRole portroles_internal[] = 
{
    {
        Capsule_PulseGenerator::port_timing,
        "Timing",
        "timing",
        "",
        0,
        false,
        false,
        false,
        false,
        true,
        false,
        false
    },
    {
        Capsule_PulseGenerator::port_log,
        "Log",
        "log",
        "",
        0,
        false,
        false,
        false,
        false,
        true,
        false,
        false
    }
};

static void instantiate_PulseGenerator( const UMLRTRtsInterface * rts, UMLRTSlot * slot, const UMLRTCommsPort * * borderPorts )
{
    const UMLRTCommsPort * * internalPorts = UMLRTFrameService::createInternalPorts( slot, &PulseGenerator );
    slot->capsule = new Capsule_PulseGenerator( &PulseGenerator, slot, borderPorts, internalPorts, false );
}

const UMLRTCapsuleClass PulseGenerator = 
{
    "PulseGenerator",
    NULL,
    instantiate_PulseGenerator,
    0,
    NULL,
    2,
    portroles_border,
    2,
    portroles_internal
};

